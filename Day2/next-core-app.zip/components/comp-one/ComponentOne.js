import React from 'react';

const ComponentOne = () => {
    return (
        <div className='para'>
            <style jsx>
                {`
                    .para {
                        font-size: 20px;
                        background-color: yellowgreen;
                    }
                `}
            </style>
            <style jsx global>
                {`
                    body {
                        background-color: lightgray;
                    }
                `}
            </style>
            <p>Hello from Component One</p>
        </div>
    );
};

export default ComponentOne;