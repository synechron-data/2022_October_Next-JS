import React from 'react';
import Product from './Product'

const Products = ({ products }) => {
    return (
        <>
            <h3>Our Products</h3>
            {
                products.map(product => (
                    <div key={product.name} className="col-md-4 pt-2 pb-5">
                        <Product product={product} />
                    </div>
                ))
            }
        </>
    );
};

export default Products;