import React, { useContext, useReducer } from 'react';

const CounterContext = React.createContext();

const initialState = { count: 0 };

const counterReducer = (state, action) => {
    switch (action.type) {
        case 'increment':
            return { count: state.count + action.payload };
        case 'decrement':
            return { count: state.count - action.payload };
        default:
            throw new Error('Invalid Action Executed...');
    }
}

const Counter = () => {
    const counter = useCountContext();

    return (
        <>
            <div className="text-center">
                <h1 className="text-info">Counter</h1>
            </div>
            <div className="d-grid gap-2 mx-auto col-6">
                <div className="text-center">
                    <h2 className="text-primary">{counter.counterState.count}</h2>
                </div>
                <button className="btn btn-primary"
                    onClick={(e) => { counter.counterDispatch({ type: 'increment', payload: 1 }); }}>
                    <span className='fs-4'>+</span>
                </button>
                <button className="btn btn-primary"
                    onClick={(e) => { counter.counterDispatch({ type: 'decrement', payload: 1 }); }}>
                    <span className='fs-4'>-</span>
                </button>
            </div>
        </>
    );
};

const CounterSibling = () => {
    const counter = useCountContext();

    return (
        <>
            <div className="text-center">
                <h1 className="text-info">Counter Sibling</h1>
            </div>
            <div className="d-grid gap-2 mx-auto col-6">
                <div className="text-center">
                    <h2 className="text-primary">{counter.counterState.count}</h2>
                </div>
                <button className="btn btn-primary"
                    onClick={(e) => { counter.counterDispatch({ type: 'increment', payload: 10 }); }}>
                    <span className='fs-4'>+</span>
                </button>
                <button className="btn btn-primary"
                    onClick={(e) => { counter.counterDispatch({ type: 'decrement', payload: 10 }); }}>
                    <span className='fs-4'>-</span>
                </button>
            </div>
        </>
    );
};

function useCountContext() {
    const counter = useContext(CounterContext);
    if (!counter) {
        throw new Error("useCountContext must be used within CountProvider");
    }
    return counter;
}

function CountProvider({ children }) {
    const [count, dispatch] = useReducer(counterReducer, initialState);

    const providerValue = { counterState: count, counterDispatch: dispatch };

    return (
        <CounterContext.Provider value={providerValue}>
            {children}
        </CounterContext.Provider>
    );
}

const CounterCustomHookDemo = () => {
    return (
        <CountProvider>
            <h2 className='text-info text-center'>Context And Reducer - Using Custom Hook</h2>
            <Counter />
            <hr />
            <CounterSibling />
        </CountProvider>
    );
};

export default CounterCustomHookDemo;