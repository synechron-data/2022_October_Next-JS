import React from 'react';
import AddTask from './AddTask';
import { TasksProvider } from './TaskContext';
import TaskList from './TaskList';

const Assignment = () => {
    return (
        <div className="d-flex justify-content-center mt-5">
            <div className="col-6">
                <div>
                    <h2>Assignment</h2>
                    <TasksProvider>
                        <AddTask />
                        <TaskList />
                    </TasksProvider>
                </div>
            </div>
        </div>
    );
};

export default Assignment;