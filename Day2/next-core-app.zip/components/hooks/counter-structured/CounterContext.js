import { createContext, useContext, useReducer } from 'react';

const CounterContext = createContext(null);
const CounterDispatchContext = createContext(null);

export function CounterProvider({ children }) {
    const [counter, dispatch] = useReducer(counterReducer, initialState);

    return (
        <CounterContext.Provider value={counter}>
            <CounterDispatchContext.Provider value={dispatch}>
                {children}
            </CounterDispatchContext.Provider>
        </CounterContext.Provider>
    );
}

export function useCounter() {
    return useContext(CounterContext);
}

export function useCounterDispatch() {
    return useContext(CounterDispatchContext);
}

const initialState = { count: 0 };

const counterReducer = (state, action) => {
    switch (action.type) {
        case 'increment':
            return { count: state.count + action.payload };
        case 'decrement':
            return { count: state.count - action.payload };
        default:
            throw new Error('Invalid Action Executed...');
    }
}