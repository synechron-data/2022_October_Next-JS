import React from 'react';

const ImageComp = () => {
    return (
        <div>
            <img src="/vercel.svg" alt="Vercel Image" />
        </div>
    );
};

export default ImageComp;