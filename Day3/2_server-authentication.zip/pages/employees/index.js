import Head from 'next/head';

import DataTable from '../../components/common/DataTable';
import { getAllEmployees } from '../../data-access/employee-repository';

import * as helpers from '../../helpers';

export default function Employees(props) {
    return (
        <>
            <Head>
                <title>Employees Page</title>
                <meta name="description" content="Created by Synechron Team" />
            </Head>

            <div className='text-center'>
                <h1 className="text-primary">Employees Page</h1>

                <>
                    <DataTable items={props.employees}>
                        <h5 className="text-primary text-uppercase font-weight-bold">Employees Table</h5>
                    </DataTable>
                </>
            </div>
        </>
    );
}

export const getServerSideProps = helpers.withSessionSsr(async function ({ req, res }) {
    const user = req.session.user;
    if (user === undefined) {
        // Redirect to Login
        return {
            redirect: {
                destination: '/login?returnUrl=employees',
                permanent: false,
            },
        }
    }
    else {
        const db_employees = await getAllEmployees();
        return {
            props: {
                // user: req.session.user,
                employees: db_employees
            }
        }
    }
});