// const rootElement = document.getElementById('app');

// const hOneElement = document.createElement('h1');
// hOneElement.className = "orange";
// hOneElement.innerText = "Hello World!";

// rootElement.appendChild(hOneElement);

// ------------------------------------------------

const myReactElement = React.createElement('h1',
    { className: 'orange' },
    "Hello World from React Element!");

ReactDOM.render(myReactElement, document.getElementById('app'));