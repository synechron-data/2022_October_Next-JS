// const myReactElement = React.createElement('h1',
//     { className: 'orange' },
//     "Hello World from React Element!");

// ReactDOM.render(myReactElement, document.getElementById('app'));

// // ------------------------------------------------ Functional Components

// const Hello = () => {
//     return React.createElement('h1',
//         { className: 'orange' },
//         "Hello World from React!");
// };

// ReactDOM.render(
//     React.createElement(Hello, {}, null),
//     document.getElementById('app')
// );

// ------------------------------------------------

const Hello = (props) => {
    return React.createElement('h1',
        { className: 'orange' },
        "Hello World from React! " + props.data);
};

ReactDOM.render(
    React.createElement(Hello, { data: new Date().toLocaleTimeString() }, null),
    document.getElementById('app')
);
