import React, { useReducer } from 'react';

const initialState = { count: 0 };

// Pure Function
const counterReducer = (state, action) => {
    switch (action.type) {
        case 'increment':
            return { count: state.count + action.payload };
        case 'decrement':
            return { count: state.count - action.payload };
        default:
            throw new Error('Invalid Action Executed...');
    }
}

const Counter = () => {
    const [state, dispatch] = useReducer(counterReducer, initialState);

    return (
        <>
            <div className="text-center">
                <h1 className="text-info">Counter using Reducer</h1>
            </div>
            <div className="d-grid gap-2 mx-auto col-6">
                <div className="text-center">
                    <h2 className="text-primary">{state.count}</h2>
                </div>
                <button className="btn btn-primary"
                    onClick={(e) => { dispatch({ type: 'increment', payload: 1 }); }}>
                    <span className='fs-4'>+</span>
                </button>
                <button className="btn btn-primary"
                    onClick={(e) => { dispatch({ type: 'decrement', payload: 1 }); }}>
                    <span className='fs-4'>-</span>
                </button>
            </div>
        </>
    );
};

const CounterSibling = () => {
    const [state, dispatch] = useReducer(counterReducer, initialState);

    return (
        <>
            <div className="text-center">
                <h1 className="text-info">Counter Sibling</h1>
            </div>
            <div className="d-grid gap-2 mx-auto col-6">
                <div className="text-center">
                    <h2 className="text-primary">{state.count}</h2>
                </div>
                <button className="btn btn-primary"
                    onClick={(e) => { dispatch({ type: 'increment', payload: 10 }); }}>
                    <span className='fs-4'>+</span>
                </button>
                <button className="btn btn-primary"
                    onClick={(e) => { dispatch({ type: 'decrement', payload: 10 }); }}>
                    <span className='fs-4'>-</span>
                </button>
            </div>
        </>
    );
};

const ReducerHookDemo = () => {
    return (
        <>
            <Counter />
            <hr />
            <CounterSibling />
        </>
    );
};

export default ReducerHookDemo;