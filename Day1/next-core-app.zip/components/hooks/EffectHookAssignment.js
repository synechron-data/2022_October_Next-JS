import React, { useEffect, useState } from 'react';

const Counter = () => {
    console.log("Counter Function Executed...");

    const [count, setCount] = useState(0);
    const [flag, setFlag] = useState(false);

    // If you are not using the variable on the UI, donot put it in state
    // const [clickCount, setClickCount] = useState(0);
    // useEffect(() => {
    //     if (count === 0) return;
    //     setClickCount(clickCount + 1);
    //     if (clickCount > 9) {
    //         setFlag(true);
    //     }
    //     console.log("useEffectExecuted: ", clickCount);
    // }, [count]);

    // let clickCount = 0;
    // useEffect(() => {
    //     if (count === 0) return;
    //     clickCount += 1;
    //     if (clickCount > 9) {
    //         setFlag(true);
    //     }
    //     console.log("useEffectExecuted: ", clickCount);
    // }, [count]);

    // let clickCount = useRef(0);
    // useEffect(() => {
    //     if (count === 0) return;
    //     clickCount.current += 1;
    //     if (clickCount.current > 9) {
    //         setFlag(true);
    //     }
    //     console.log("useEffectExecuted: ", clickCount);
    // }, [count]);

    let clickCount = useRef(0);
    let isInitialState = useRef(true);

    useEffect(() => {
        if (isInitialState.current) {
            isInitialState.current = false;
        } else {
            clickCount.current += 1;
            if (clickCount.current > 9) {
                setFlag(true);
            }
            console.log("useEffectExecuted: ", clickCount);
        }
    }, [count]);

    function reset(e) {
        setCount(0);
        setFlag(false);
        clickCount.current = 0;
    }

    return (
        <>
            <div className="text-center">
                <h1 className="text-info">Counter</h1>
            </div>
            <div className="d-grid gap-2 mx-auto col-6">
                <div className="text-center">
                    <h2 className="text-primary">{count}</h2>
                </div>
                <button className="btn btn-primary" disabled={flag}
                    onClick={(e) => { setCount(count + 1); }}>
                    <span className='fs-4'>+</span>
                </button>
                <button className="btn btn-primary" disabled={flag}
                    onClick={(e) => { setCount(count - 1); }}>
                    <span className='fs-4'>-</span>
                </button>
                <button className="btn btn-primary" disabled={!flag}
                    style={!flag ? { cursor: 'not-allowed', pointerEvents: 'all' } : {}}
                    onClick={(e) => { reset(e); }}>
                    <span className='fs-4'>Reset</span>
                </button>
            </div>
        </>
    );
};

const EffectHookAssignment = () => {
    return (
        <Counter />
    );
};

export default EffectHookAssignment;